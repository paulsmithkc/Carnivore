MAC

Before running Carnivore, you must run this command in Terminal:

	sudo chmod 777 /dev/bpf*

This must be done after each time you restart your mac. 

+ + +


WINDOWS

Winpcap (www.winpcap.org) is required.

Our testing machine is a Dell Latitude running Windows 8 (32bit). If you
have problems on other configurations, please let us know.
